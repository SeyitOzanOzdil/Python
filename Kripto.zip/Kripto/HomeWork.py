import numpy as np


def gcd(x, y):
    hcf = 0
    if x > y:
        smaller = y
    else:
        smaller = x
    for i in range(1, smaller + 1):
        if (x % i == 0) and (y % i == 0):
            hcf = i

    return hcf


def numberReverse():
    mod = int(input("Mod değerini giriniz: "))
    number = int(input("Tersi hesaplanacak sayıyı giriniz: "))
    _gcd = gcd(number, mod)
    inverse = 0
    if _gcd != 1:
        print("mod ve sayı aralarında asal değil ")
    else:
        for i in range(9):
            if ((i * number) % mod == 1) and (gcd(i, mod) == 1):
                inverse = i
                break
        if (inverse == 0):
            print("Sayının mod değerine göre tersi yoktur.")
        else:
            print("Sayının tersi: " + str(inverse))


r = [[1, 0, 0, 0, 1, 1, 0, 1, 1]]
q = []
t = [[0], [1]]


def getMod(lst):
    for i in range(len(lst)):
        lst[i] = int(lst[i]) % 2
    return lst


def euclideanAlgorithm():
    r0 = np.array(r[len(r) - 2])
    r1 = np.array(r[len(r) - 1])
    q1, r2 = np.polydiv(r0, r1)
    r.append(getMod(r2))
    q.append(getMod(q1))
    return


def findAuxiliaryPolynomia():
    t0 = np.array(t[len(t) - 2])
    t1 = np.array(t[len(t) - 1])
    t2 = np.polysub(t0, np.polymul(t1, q[len(q) - 1]))
    t.append(getMod(t2))
    return


def extendedEuclideanAlgorithm():
    degree = int(input("Polinom derecesini giriniz(max 7): "))
    while degree > 7:
        degree = int(input("Hatalı girdi! Polinom derecesini giriniz(max 7): "))
    polinom = list((input("Katsayıları giriniz(Derece 4 için örnek input = 10111): ")))
    while len(polinom) != degree + 1:
        polinom = list((input("Hatalı girdi! Katsayıları giriniz(Derece 4 için örnek input = 10111): ")))
    r.append(getMod(polinom))
    flag = True

    while flag:
        euclideanAlgorithm()
        if r[len(r) - 1][0] == 0:
            flag = False
        else:
            findAuxiliaryPolynomia()

    output = ""
    coef = len(t[len(t) - 1])
    for i in t[len(t) - 1]:
        coef -= 1
        if i != 0:
            if (output == ""):
                output = output + "x^" + str(coef)
            else:
                output = output + " + " + "x^" + str(coef)
    print(output)


def main():
    choise = int(input("Sayının tersini almak için 0'a polinom tersi için 1'e basınız: "))
    while choise != 0 and choise != 1:
        choise = int(input("Hatalı Seçim! Sayının tersini almak için 0'a polinom tersi için 1'e basınız: "))
    if (choise == 0):
        numberReverse()
    else:
        extendedEuclideanAlgorithm()

    key = input("Çıkmak için bir tuşa basınız: ")


main()
